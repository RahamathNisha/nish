package controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

/**
 * Handles requests for the application file upload requests
 */
@Controller
public class FileUploadController {
	
	private static final Logger logger = LoggerFactory
			.getLogger(FileUploadController.class);

	@RequestMapping(value = "/FileUploadSuccess", method = RequestMethod.POST)
	public String uploadFileHandler(@RequestParam("file") MultipartFile file,HttpServletRequest request) {

		if (!file.isEmpty()) {
			try {
				System.out.println("IN is empty");
				//byte[] bytes = file.getBytes();
				// Creating the directory to store file
				/*String rootPath = "E:/1workspace/demo/src/main/webapp/WEB-INF/resources/images";
				File dir = new File(rootPath + File.separator + file);
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath()
						+ File.separator + file.getOriginalFilename());
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();*/
				String n = request.getParameter("name");
				String rootDirectory = request.getSession().getServletContext().getRealPath("/");
		        Path path = Paths.get(rootDirectory + "\\WEB-INF\\resources\\images\\"+n+".jpg");
		        file.transferTo(new File(path.toString()));
				logger.info("Server File Location="
						+ path.toString());
				
				
				return "redirect:/productpage";
			} catch (Exception e) {
				return "You failed to upload " + file + " => " + e.getMessage();
			}
		} else {
			return "You failed to upload " + file
					+ " because the file was empty.";
		}
	}

 
       
}    
